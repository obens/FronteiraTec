#include <stdio.h>
#include <stdlib.h>
#include <string.h>



// 1  Escreva um algoritmo que solicite ao 
//usuário as notas de três provas (P1, P2, P3) e seus
//respectivos pesos (W1, W2, W3).


int main(int argc, char const *argv[])
{
	
float p1, p2,p3;
float w1, w2, w3;
float media;
//string aprovado;
printf(" digite o valor da primeira nota: ");
scanf("%f",&p1);
printf(" digite o valor da segunda nota: ");
scanf("%f",&p2);
printf(" digite o valor da terceira nota: ");
scanf("%f",&p3);

printf("digite o peso da p1:\n ");
scanf("%f", &w1);
printf("digite o peso da p2\n: ");
scanf("%f", &w2);
printf("digite o peso da p3\n: ");
scanf("%f", &w3);

return 0;

	}

	
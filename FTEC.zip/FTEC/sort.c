// resolvendo aqui usando a logica do bubble sort que é um algoritmo de ordenação.

#include <stdlib.h>
#include <stdio.h>


int main(){

	int i, j,n,aux;
	printf("digite o tamanho do vetor: ");
	scanf("%d", &n);
	int vet[n];
	printf("digite os valores do vetor\n");
	for(i=0; i<n; i++){
		printf("digite o valor %d: ", i+1);
		scanf("%d", &vet[i]);
	}
	//n= (int) sizeof(vet)/sizeof(int);
		  	
		
		for(i = n-1; i!=0; i--)
		{
			for(j = 0; j <  i ; j++)
			{
				if(vet[j] > vet[j+1] )
				{
					aux = vet[j];
					vet[j] = vet[j+1];
					vet[j+1] = aux;
				}
			}
		}
		printf("valores_ordenados\n");	
		for(i = 0; i !=n-1; i++){
  			printf("%d ", vet[i]);
  		}
		    printf("\n\n");	      
        
    	    
    return 0;

}